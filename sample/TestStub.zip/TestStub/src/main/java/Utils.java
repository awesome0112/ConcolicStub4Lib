public class Utils {
    public static int max(int x, int y) {
        if (x > y) return x;
        else return y;
    }

    public static int min(int x, int y) {
        if (x < y) return x;
        else return y;
    }

    public static int testStub(int x, int y) {
        int max = 0;
        if (max(x, y) == x) {
            max = x;
        } else {
            max = y;
        }
        return max;
    }
}
