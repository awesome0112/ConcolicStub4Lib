public class UnitsHaveInClassMethodInvocation {
    public static boolean isLeapYear(int year) {
        if (year % 4 == 0) {
            if (year % 100 == 0) {
                if (year % 400 == 0) return true;
                else return false;
            }
            else {
                return true;
            }
        }
        return false;
    }

    private static int getNumberOfDays(int month, int year) {
        int numOfDays = 0;
        for (int i = 1; i <= month; i++) {
            if (i == 2) {
                if(isLeapYear(year)) {
                    numOfDays += 29;
                }
                else numOfDays += 28;
            } else if (i <= 7) {
                if (i % 2 == 0) numOfDays += 30;
                else numOfDays += 31;
            } else {
                if (i % 2 == 0) numOfDays += 31;
                else numOfDays += 30;
            }
        }
        return numOfDays;
    }

    public boolean isArmstrong(double N) {
        int n = getLength(N);
        if (getNthPowerSum(N, n) == N) return true;
        else return false;
    }

    public static double pow(double a, double b) {
        double res = 1;
        for (int i = 0; i < b; i++) {
            res *= a;
        }
        return res;
    }

    public static double getNthPowerSum(double n, double p) {
        double sum = 0;
        while (n > 0) {
            double temp = n % 10;
            n /= 10;
            sum += pow(temp, p);
        }

        return sum;
    }

    public static int getLength(double n) {
        int count = 0;
        while (n > 0) {
            n /= 10;
            count++;
        }
        return count;
    }
}
